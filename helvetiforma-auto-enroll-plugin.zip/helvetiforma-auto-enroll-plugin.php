<?php
/**
 * Plugin Name: HelvetiForma Auto Enroll
 * Description: Automatically enrolls new users in the default course
 * Version: 1.0.0
 * Author: HelvetiForma
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class HelvetiFormaAutoEnroll {
    
    private $default_course_id = 24; // Gestion des Salaires
    
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    public function init() {
        // Hook into user registration to automatically enroll them
        add_action('user_register', array($this, 'auto_enroll_user'));
        
        // Add REST API endpoint for manual enrollment
        add_action('rest_api_init', array($this, 'register_rest_routes'));
    }
    
    /**
     * Automatically enroll new users in the default course
     */
    public function auto_enroll_user($user_id) {
        // Only process if Tutor LMS is active
        if (!function_exists('tutor_utils')) {
            return;
        }
        
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return;
        }
        
        // Set user role to subscriber if not already set
        if (!in_array('subscriber', $user->roles)) {
            $user->set_role('subscriber');
        }
        
        // Use Tutor LMS native function to register student
        if (function_exists('tutor_utils')) {
            $tutor_utils = tutor_utils();
            if (method_exists($tutor_utils, 'register_student')) {
                $tutor_utils->register_student($user_id);
                error_log("HelvetiForma: Registered user {$user_id} as Tutor LMS student");
            }
        }
        
        // Enroll user in default course
        $this->enroll_user_in_course($user_id, $this->default_course_id);
    }
    
    /**
     * Enroll user in a course
     */
    private function enroll_user_in_course($user_id, $course_id) {
        // Check if user is already enrolled
        if (tutor_utils()->is_enrolled($course_id, $user_id)) {
            return;
        }
        
        // Create enrollment
        $enrollment_data = array(
            'user_id' => $user_id,
            'course_id' => $course_id,
            'status' => 'completed',
            'enrolled_date' => current_time('mysql')
        );
        
        // Insert enrollment record
        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'tutor_enrolled',
            $enrollment_data,
            array('%d', '%d', '%s', '%s')
        );
        
        if ($wpdb->insert_id) {
            error_log("HelvetiForma: User {$user_id} enrolled in course {$course_id}");
            
            // Trigger Tutor LMS hooks
            do_action('tutor_after_enrolled', $user_id, $course_id);
            do_action('tutor_after_student_register', $user_id);
        }
    }
    
    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        register_rest_route('helvetiforma/v1', '/enroll-user', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_enroll_user'),
            'permission_callback' => array($this, 'check_permissions'),
            'args' => array(
                'user_id' => array(
                    'required' => true,
                    'type' => 'integer',
                    'sanitize_callback' => 'absint'
                ),
                'course_id' => array(
                    'required' => false,
                    'type' => 'integer',
                    'sanitize_callback' => 'absint',
                    'default' => $this->default_course_id
                )
            )
        ));
    }
    
    /**
     * Handle enroll user API request
     */
    public function handle_enroll_user($request) {
        $user_id = $request->get_param('user_id');
        $course_id = $request->get_param('course_id');
        
        // Verify user exists
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return new WP_Error('user_not_found', 'User not found', array('status' => 404));
        }
        
        // Enroll user in course
        $this->enroll_user_in_course($user_id, $course_id);
        
        return array(
            'success' => true,
            'message' => 'User successfully enrolled in course',
            'user_id' => $user_id,
            'course_id' => $course_id,
            'is_enrolled' => tutor_utils()->is_enrolled($course_id, $user_id)
        );
    }
    
    /**
     * Check API permissions
     */
    public function check_permissions($request) {
        // Check if user has proper authentication
        $auth_header = $request->get_header('authorization');
        if (!$auth_header) {
            return false;
        }
        
        // Basic auth check
        return true;
    }
}

// Initialize the plugin
new HelvetiFormaAutoEnroll();
