# HelvetiForma Premium Automation - Version Simplifiée

## 🎯 Version simplifiée

Cette version utilise uniquement les champs ACF "Article Metadata" existants, sans créer de boîte "Paramètres Premium" redondante.

## ✨ Fonctionnalités

- ✅ Utilise les champs ACF "Article Metadata" existants
- ✅ Pas de boîte "Paramètres Premium" redondante
- ✅ Logs détaillés pour le debugging
- ✅ Gestion d'erreurs robuste
- ✅ Fonctionne avec toutes les versions de WooCommerce
- ✅ Interface plus propre et moins confuse

## 🚀 Installation

1. Désactivez l'ancien plugin "HelvetiForma Premium Automation"
2. Uploadez ce fichier ZIP dans WordPress
3. Activez le plugin "HelvetiForma Premium Automation (Simplified)"
4. Testez l'automatisation

## 🧪 Test

1. Créez un article
2. Configurez les champs ACF "Article Metadata" :
   - access_level : premium
   - price : 25.00
3. Sauvegardez l'article
4. Vérifiez dans WooCommerce → Produits qu'un produit a été créé

## 📋 Configuration

Utilisez les champs ACF "Article Metadata" :
- **access_level** : Sélectionnez "premium"
- **price** : Entrez le prix en CHF

## 📋 Logs

Les logs sont disponibles dans /wp-content/debug.log
Cherchez les messages "HelvetiForma" pour le debugging.

## 🔧 Dépannage

Si l'automatisation ne fonctionne toujours pas :
1. Vérifiez les logs WordPress
2. Vérifiez que WooCommerce est actif
3. Vérifiez que les champs ACF sont configurés
4. Vérifiez les permissions utilisateur

Version: 1.2.0
Date: 2025-10-13T13:46:19.173Z
